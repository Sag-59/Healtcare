<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $doctorId = $_POST['consulting_doctor_id'];
    $appointmentDate = $_POST['appointment_date'];
    $appointmentTime = $_POST['appointment_time'];
    $notes = $_POST['notes'];

    $sql = "INSERT INTO Appointments (full_name, email, phone, consulting_doctor_id, appointment_date, appointment_time, notes)
            VALUES (:full_name, :email, :phone, :consulting_doctor_id, :appointment_date, :appointment_time, :notes)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':full_name' => $fullName,
        ':email' => $email,
        ':phone' => $phone,
        ':consulting_doctor_id' => $doctorId,
        ':appointment_date' => $appointmentDate,
        ':appointment_time' => $appointmentTime,
        ':notes' => $notes
    ]);

    // Redirect to the success page with a custom message
    header("Location: ../success.html?message=Appointment+booked+successfully");
    exit();
}
