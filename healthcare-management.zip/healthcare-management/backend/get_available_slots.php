<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $doctorId = $_GET['doctor_id'];
    $appointmentDate = $_GET['appointment_date'];

    if (!$doctorId || !$appointmentDate) {
        echo json_encode(['error' => 'Missing parameters']);
        exit();
    }

    // Define the working hours for appointments
    $startTime = strtotime("14:00"); // Start time: 2:00 PM
    $endTime = strtotime("20:00");   // End time: 8:00 PM

    $allSlots = [];
    while ($startTime < $endTime) {
        $allSlots[] = date("H:i", $startTime);
        $startTime = strtotime("+30 minutes", $startTime); // Increment by 30 minutes
    }

    // Fetch booked slots for the specified doctor and date
    $sql = "SELECT appointment_time FROM Appointments 
            WHERE consulting_doctor_id = :doctor_id AND appointment_date = :appointment_date";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':doctor_id' => $doctorId, ':appointment_date' => $appointmentDate]);
    $bookedSlots = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Filter available slots
    $availableSlots = array_diff($allSlots, $bookedSlots);

    // Return available slots as JSON
    echo json_encode(array_values($availableSlots));
    exit();
}
