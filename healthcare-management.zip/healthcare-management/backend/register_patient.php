<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $dob = $_POST['date_of_birth'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $problem = $_POST['problem'];
    $consultingDoctor = $_POST['consulting_doctor_id'];

    $sql = "INSERT INTO Patients (full_name, email, phone, date_of_birth, gender, address, problem, consulting_doctor_id)
            VALUES (:full_name, :email, :phone, :date_of_birth, :gender, :address, :problem, :consulting_doctor_id)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':full_name' => $fullName,
        ':email' => $email,
        ':phone' => $phone,
        ':date_of_birth' => $dob,
        ':gender' => $gender,
        ':address' => $address,
        ':problem' => $problem,
        ':consulting_doctor_id' => $consultingDoctor
    ]);

    // Redirect to the success page with a custom message
    header("Location: ../success.html?message=Patient+registered+successfully");
    exit();
}
