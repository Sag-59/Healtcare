<?php
require 'config.php';

$sql = "SELECT id, name, specialization FROM Doctors";
$result = $conn->query($sql);

$doctors = $result->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($doctors);
