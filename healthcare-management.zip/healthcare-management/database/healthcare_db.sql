CREATE DATABASE IF NOT EXISTS healthcare_db;
USE healthcare_db;

CREATE TABLE Doctors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    specialization VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(15)
);

CREATE TABLE Patients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(15),
    date_of_birth DATE NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    address TEXT,
    problem VARCHAR(255) NOT NULL,
    consulting_doctor_id INT NOT NULL,
    FOREIGN KEY (consulting_doctor_id) REFERENCES Doctors(id)
);

CREATE TABLE Appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    consulting_doctor_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    notes TEXT,
    FOREIGN KEY (consulting_doctor_id) REFERENCES Doctors(id)
);

-- Insert 10 Indian doctors
INSERT INTO Doctors (name, specialization, email, phone)
VALUES
    ('Dr. Rajesh Sharma', 'Cardiologist', 'rajesh.sharma@example.com', '9876543210'),
    ('Dr. Meera Nair', 'Dermatologist', 'meera.nair@example.com', '9876543211'),
    ('Dr. Vikram Arora', 'Orthopedic', 'vikram.arora@example.com', '9876543212'),
    ('Dr. Priya Patel', 'Pediatrician', 'priya.patel@example.com', '9876543213'),
    ('Dr. Arjun Rao', 'Neurologist', 'arjun.rao@example.com', '9876543214'),
    ('Dr. Kavita Joshi', 'Psychiatrist', 'kavita.joshi@example.com', '9876543215'),
    ('Dr. Anil Kumar', 'General Physician', 'anil.kumar@example.com', '9876543216'),
    ('Dr. Sneha Iyer', 'Gynecologist', 'sneha.iyer@example.com', '9876543217'),
    ('Dr. Nikhil Verma', 'Oncologist', 'nikhil.verma@example.com', '9876543218'),
    ('Dr. Pooja Bansal', 'ENT Specialist', 'pooja.bansal@example.com', '9876543219');
