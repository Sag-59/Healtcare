document.addEventListener("DOMContentLoaded", function () {
    const doctorDropdown = document.getElementById("doctor-select");
    const dateInput = document.getElementById("appointment-date");
    const today = new Date().toISOString().split("T")[0]; // Get today's date in "YYYY-MM-DD" format
    dateInput.setAttribute("min", today); // Set min attribute
    const timeSlotDropdown = document.getElementById("time-slot-select");

    // Fetch doctors for dropdown (already implemented)
    fetch("backend/get_doctors.php")
        .then(response => response.json())
        .then(data => {
            doctorDropdown.innerHTML = '<option value="">Select Doctor</option>';
            data.forEach(doctor => {
                const option = document.createElement("option");
                option.value = doctor.id;
                option.textContent = `${doctor.name} (${doctor.specialization})`;
                doctorDropdown.appendChild(option);
            });
        })
        .catch(error => console.error("Error fetching doctors:", error));

    // Fetch available slots when doctor and date are selected
    function fetchAvailableSlots() {
        const doctorId = doctorDropdown.value;
        const appointmentDate = dateInput.value;

        if (doctorId && appointmentDate) {
            fetch(`backend/get_available_slots.php?doctor_id=${doctorId}&appointment_date=${appointmentDate}`)
                .then(response => response.json())
                .then(data => {
                    timeSlotDropdown.innerHTML = '<option value="">Select Time Slot</option>';
                    if (data.error) {
                        console.error(data.error);
                        return;
                    }
                    

                    data.forEach(slot => {
                        const option = document.createElement("option");
                        option.value = slot;
                        option.textContent = slot;
                        timeSlotDropdown.appendChild(option);
                    });
                })
                .catch(error => console.error("Error fetching slots:", error));
        }
    }

    doctorDropdown.addEventListener("change", fetchAvailableSlots);
    dateInput.addEventListener("change", fetchAvailableSlots);
});
